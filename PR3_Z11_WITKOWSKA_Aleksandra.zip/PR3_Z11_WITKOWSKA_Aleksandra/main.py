import tkinter as gui
from tkinter import OptionMenu, StringVar
from PIL import ImageTk
from openpyxl import load_workbook

def restart():
    root.destroy()
    main()

def main():
    lista = []
    wb = load_workbook('Loty baza.xlsx')
    sheet = wb.active
    for row in sheet.iter_rows(min_row=4, min_col=13, max_row=44, max_col=13):
        for cell in row:
            lista.append(cell.value)

    n = (len(lista))

    cena = {}
    keys = lista

    for i in keys:
        listadokad = []
        for row in range(5, 208):
            if (i ==sheet.cell(row, column=3).value):
                listadokad.append(sheet.cell(row, column=4).value)
                listadokad.append(sheet.cell(row, column=5).value)
        co_druga = listadokad[::2]  # ['klucz', 'klucz1', 'klucz2']
        co_druga_od_drugiej = listadokad[1::2]  # ['wartosc', 'wartosc1']
        pary = zip(co_druga, co_druga_od_drugiej)
        slow = dict(pary)
        cena[i] = slow


    czas = {}
    for i in keys:
        listadokad = []
        for row in range(5, 208):
            if (i ==sheet.cell(row, column=3).value):
                listadokad.append(sheet.cell(row, column=4).value)
                listadokad.append(sheet.cell(row, column=6).value)
        co_druga = listadokad[::2]  # ['klucz', 'klucz1', 'klucz2']
        co_druga_od_drugiej = listadokad[1::2]  # ['wartosc', 'wartosc1']
        pary = zip(co_druga, co_druga_od_drugiej)
        slow = dict(pary)
        czas[i] = slow


    def dijkstry(graph, start, goal):
        min_odleglosc = {} #Zapamiętuje koszt dotarcia do danego wierzchołka - będzie aktualizowany w miare poruszania się po grafie#
        poprzednik = {} #Zapamiętuje trasę, która doprowadziła nas do danego wierzchołka#
        nieodwiedzone = graph #słownik stworzony aby upewnić się, że każdy wierzchołek grafu zpstanie sprawdzony#
        infinity = 9999999 #Przyjmujemy liczbę na tyle dużą, że przewyższa każdy możliwy do uzyskania koszt#
        trasa = [] #będzie odtwarzać naszą podróż aż do wyjściowego wierzchołka#

        for node in nieodwiedzone:
            min_odleglosc[node] = infinity
        min_odleglosc[start] = 0

        while nieodwiedzone:  #zostajemy w pętli dopóki słownik nie zostanie opróżniony - wszytskie wierzchołki odwiedzone#

            min_distance_node = None

            for node in nieodwiedzone:
                if min_distance_node is None:
                    min_distance_node = node

                elif min_odleglosc[node] < min_odleglosc[min_distance_node]:
                    min_distance_node = node

            trasa_option = graph[min_distance_node].items() #wypisuje słownik przypisany jako wartość do klucza min_distance_node jako listę złożoną z dwuczłonowych tupli#

            for child_node, koszt in trasa_option: #wyszukuje możliwe krótsze połączenia#
                if koszt + min_odleglosc[min_distance_node] < min_odleglosc[child_node]:
                    min_odleglosc[child_node] = koszt + min_odleglosc[min_distance_node]
                    poprzednik[child_node] = min_distance_node
            nieodwiedzone.pop(min_distance_node) #usuwamy sprawdzony wierzchołek ze słownika#


        currentnode = goal

        while currentnode != start: #chcemy odtworzyć całą trasę aż do wyjściowego wierzchołka#
            try:
                trasa.insert(0, currentnode)
                currentnode = poprzednik[currentnode]

            except KeyError:
                print("Path is not reachable")

                break


        trasa.insert(0, start)

        final_str="Trasa niedostępna"


        if min_odleglosc[goal] != infinity:

            if(graph == czas):
                final_str = "Najszybsza droga  "+ str(start) + " do " + str(goal) + ' ' + "zajmie  " + ' ' + str(min_odleglosc[goal]) + 'h' + '\n' + "Przebieg podróży:  " + str(trasa)
            elif(graph == cena):
                final_str = "Koszt najtańszej trasy z " + str(start) + " do " + str(goal) + " wyniesie: " + ' ' +  str(min_odleglosc[goal]) + '\n' + "Przebieg podróży " + str(trasa)

        return final_str


    global root
    root = gui.Tk()



    clicked1 = StringVar()
    clicked1.set("SKĄD")
    clicked2 = StringVar()
    clicked2.set("DOKĄD")
    clicked3 = StringVar()
    clicked3.set("PRIORYTET")


    def wywołaj():
        if (str(clicked3.get()) == "cena"):
                label['text'] = dijkstry(cena, clicked1.get(), clicked2.get())

        elif(str(clicked3.get()) == "czas"):
                label['text']=dijkstry(czas, clicked1.get(), clicked2.get())

        return(label)


    canvas = gui.Canvas(root, height = 600, width = 700)
    canvas.pack()

    background_image = ImageTk.PhotoImage(file='bg1_image.jpg')
    background_label = gui.Label(root, image=background_image)
    background_label.place(relwidth=1, relheight=1)

    frame = gui.Frame(root, bg='#80c1ff')
    frame.place(relx=0.1, rely=0.1, relwidth=0.8, relheight=0.8)

    l1 = gui.Label(frame, text="Wybierz skąd")
    l1.place(relx=0.1, rely=0.02, relwidth=0.2)
    l2 = gui.Label(frame, text="Wybierz dokąd")
    l2.place(relx= 0.4, rely=0.02, relwidth=0.2)
    l3 = gui.Label(frame, text="Jaki jest twój priorytet?")
    l3.place(relx=0.65, rely=0.02, relwidth=0.3)

    drop1 = OptionMenu(frame, clicked1, *lista)
    drop1.place(relx=0.1, rely=0.1, relwidth=0.2)
    drop2 = OptionMenu(frame, clicked2, *lista)
    drop2.place(relx=0.4, rely=0.1, relwidth=0.2)
    drop3 = OptionMenu(frame, clicked3, "cena", "czas")
    drop3.place(relx=0.65, rely=0.1, relwidth=0.2)

    Mybutton = gui.Button(frame, text="SZUKAJ", command=lambda: wywołaj())
    Mybutton.place(relx=0.4, rely=0.22, relwidth=0.2)
    Mybutton2 = gui.Button(frame, text="znajdź nową trasę", command=lambda: restart())
    Mybutton2.place(relx=0.4, rely=0.9, relwidth=0.25)
    lower_frame = gui.Frame(root, bg='#80c1ff', bd=10)
    lower_frame.place(relx=0.5, rely=0.35, relwidth=0.7, relheight=0.45, anchor='n')


    label = gui.Label(lower_frame)
    label.place(relwidth=1, relheight=1)

    root.mainloop()
main()








